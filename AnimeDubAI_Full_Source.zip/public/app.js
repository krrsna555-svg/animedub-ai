const $ = (s) => document.querySelector(s);
let currentUser = null;
let authMode = "login";
let toastTimer;

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function setUser(user) {
  currentUser = user || null;
  $("#accountLabel").textContent = user ? `${user.email} · ${user.plan.toUpperCase()}` : "Not signed in";
  $("#authOpen").classList.toggle("hidden", !!user);
  $("#logoutBtn").classList.toggle("hidden", !user);
  $("#adminSection").classList.toggle("hidden", !user || user.role !== "admin");
  $("#dubStatus").textContent = user ? "Ready to receive your authorized video. Real AI processing is not configured yet." : "Sign in to submit a project. AI processing is not configured yet.";
  loadJobs();
  if (user?.role === "admin") loadAdmin();
}
function showAuth(mode = "login") {
  authMode = mode;
  $("#authTitle").textContent = mode === "login" ? "Sign in" : "Create your account";
  $("#authSubmit").textContent = mode === "login" ? "Sign in" : "Create account";
  $("#toggleAuth").textContent = mode === "login" ? "Need an account? Register" : "Already registered? Sign in";
  $("#authError").textContent = "";
  $("#authDialog").showModal();
}
$("#authOpen").addEventListener("click", () => showAuth("login"));
$("#toggleAuth").addEventListener("click", () => showAuth(authMode === "login" ? "register" : "login"));
$("#authForm").addEventListener("submit", async e => {
  e.preventDefault();
  const button = $("#authSubmit");
  button.disabled = true;
  $("#authError").textContent = "";
  try {
    const data = await api(`/api/auth/${authMode}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: $("#email").value, password: $("#password").value })
    });
    setUser(data.user);
    $("#authDialog").close();
    toast(authMode === "login" ? "Signed in successfully." : "Account created.");
  } catch (err) {
    $("#authError").textContent = err.message;
  } finally { button.disabled = false; }
});
$("#logoutBtn").addEventListener("click", async () => {
  try { await api("/api/auth/logout", { method: "POST" }); setUser(null); toast("Signed out."); }
  catch (e) { toast(e.message); }
});

$("#searchForm").addEventListener("submit", async e => {
  e.preventDefault();
  const q = $("#searchInput").value.trim();
  if (!q) return;
  const container = $("#animeResults");
  container.innerHTML = '<div class="empty-state">Searching anime…</div>';
  try {
    const data = await api(`/api/library/search?q=${encodeURIComponent(q)}`);
    if (!data.results.length) { container.innerHTML = '<div class="empty-state">No matches found. Try another title.</div>'; return; }
    container.innerHTML = data.results.map(a => `
      <article class="anime-card">
        <img src="${escapeHTML(a.cover || "")}" alt="" loading="lazy" referrerpolicy="no-referrer">
        <div class="anime-info"><h3>${escapeHTML(a.title)}</h3>
          <p>${escapeHTML([a.year, a.format, a.episodes ? `${a.episodes} eps` : ""].filter(Boolean).join(" · "))}</p>
          <button type="button" data-anime="${a.id}">Use this title</button>
        </div>
      </article>`).join("");
    container.querySelectorAll("[data-anime]").forEach(button => button.addEventListener("click", () => {
      $("#studio").scrollIntoView({ behavior: "smooth" });
      toast("Selected anime metadata. Upload an authorized episode video to continue.");
    }));
  } catch (err) {
    container.innerHTML = `<div class="empty-state">${escapeHTML(err.message)}</div>`;
  }
});

$("#dubForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!currentUser) { showAuth("login"); return; }
  if (!$("#rightsConfirmed").checked) { toast("Please confirm you have permission to process this video."); return; }
  const video = $("#video").files[0];
  if (!video) { toast("Choose a video file first."); return; }
  const button = $("#dubBtn");
  button.disabled = true;
  $("#dubStatus").textContent = "Uploading…";
  try {
    const form = new FormData();
    form.append("video", video);
    form.append("language", $("#language").value);
    form.append("rightsConfirmed", "true");
    const data = await api("/api/dub", { method: "POST", body: form });
    $("#dubStatus").textContent = data.message;
    toast("Project received.");
    await loadJobs();
  } catch (err) {
    $("#dubStatus").textContent = err.message;
  } finally { button.disabled = false; }
});

async function loadJobs() {
  const container = $("#jobsList");
  if (!currentUser) { container.innerHTML = '<div class="empty-state">Sign in to see your projects.</div>'; return; }
  try {
    const data = await api("/api/jobs");
    const limit = data.dailyLimit === null ? "Pro quota" : `${data.dailyUsed}/${data.dailyLimit} completed today (UTC)`;
    if (!data.jobs.length) { container.innerHTML = `<div class="empty-state">No projects yet. Upload an authorized episode to get started.<br><br>${escapeHTML(limit)}</div>`; return; }
    container.innerHTML = `<div class="fineprint">${escapeHTML(limit)}</div>` + data.jobs.map(j => `
      <div class="job-row"><div><div class="job-name">${escapeHTML(j.originalName)}</div><div class="job-sub">${escapeHTML(j.language)} · ${escapeHTML(new Date(j.createdAt + (j.createdAt.endsWith("Z") ? "" : "Z")).toLocaleString())}</div></div><div class="job-status">${escapeHTML(j.status.replaceAll("_", " "))}<div class="job-sub">${escapeHTML(j.message)}</div></div></div>`).join("");
  } catch (err) { container.innerHTML = `<div class="empty-state">${escapeHTML(err.message)}</div>`; }
}
$("#refreshJobs").addEventListener("click", loadJobs);
$("#freePlanBtn").addEventListener("click", () => { document.querySelector("#studio").scrollIntoView({ behavior: "smooth" }); toast("The Free plan is selected by default."); });
$("#proPlanBtn").addEventListener("click", () => {
  $("#proPayment").scrollIntoView({ behavior: "smooth", block: "center" });
  toast("Choose a plan and scan the UPI QR. Pro requires payment verification.");
});
$("#copyUpiBtn").addEventListener("click", async () => {
  const upi = $("#upiId").textContent.trim();
  try {
    await navigator.clipboard.writeText(upi);
    toast("UPI ID copied.");
  } catch {
    const range = document.createRange(); range.selectNodeContents($("#upiId"));
    const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
    toast("Select and copy the UPI ID shown.");
  }
});
async function loadAdmin() {
  if (!currentUser || currentUser.role !== "admin") return;
  try {
    const data = await api("/api/admin/overview");
    $("#adminStats").innerHTML = [
      ["Users", data.users], ["Projects", data.jobs], ["Awaiting / active", data.pending], ["Active Pro", data.activePro], ["Failed jobs", data.failures]
    ].map(([label, n]) => `<div class="stat"><strong>${Number(n)}</strong><span>${escapeHTML(label)}</span></div>`).join("");
    const jobs = await api("/api/admin/jobs");
    $("#adminJobs").innerHTML = `<b>Recent projects</b>` + (jobs.jobs.length ? jobs.jobs.map(j => `<div class="job-row"><div><div class="job-name">${escapeHTML(j.originalName)}</div><div class="job-sub">User #${j.userId} · ${escapeHTML(j.language)}</div></div><div class="job-status">${escapeHTML(j.status)}</div></div>`).join("") : '<div class="empty-state">No projects yet.</div>');
  } catch (err) { $("#adminStats").innerHTML = `<div class="notice">${escapeHTML(err.message)}</div>`; }
}
$("#refreshAdmin").addEventListener("click", loadAdmin);
(async function init() {
  try { const data = await api("/api/me"); setUser(data.user); }
  catch { setUser(null); }
})();